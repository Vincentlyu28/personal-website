import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  ArrowRight, 
  Brain, 
  Activity, 
  Globe, 
  Lightbulb, 
  Mail, 
  Menu, 
  X, 
  ChevronRight,
  Stethoscope,
  Dna,
  Microscope
} from 'lucide-react';

export default function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: '关于我', href: '#about' },
    { name: '破界实验室', href: '#lab' },
    { name: 'AI医疗洞察', href: '#insights' },
    { name: '其他IP', href: '#ips' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-blue-200 selection:text-blue-900">
      {/* Navigation */}
      <header 
        className={`fixed top-0 w-full z-50 transition-all duration-300 ${
          isScrolled ? 'bg-white/80 backdrop-blur-md shadow-sm py-4' : 'bg-transparent py-6'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center">
          <a href="#" className="text-xl font-bold tracking-tighter flex items-center gap-2 group">
            <Brain className="w-6 h-6 text-blue-600 group-hover:scale-110 transition-transform" />
            <span>破界<span className="text-blue-600">实验室</span></span>
          </a>
          
          {/* Desktop Nav */}
          <nav className="hidden md:flex gap-8">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href}
                className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-all relative py-1 after:content-[''] after:absolute after:w-full after:scale-x-0 after:h-0.5 after:bottom-0 after:left-0 after:bg-blue-600 after:origin-bottom-right after:transition-transform after:duration-300 hover:after:scale-x-100 hover:after:origin-bottom-left"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden text-slate-900"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Nav */}
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute top-full left-0 w-full bg-white shadow-lg py-4 px-6 flex flex-col gap-4 md:hidden"
          >
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-base font-medium text-slate-800 hover:text-blue-600"
              >
                {link.name}
              </a>
            ))}
          </motion.div>
        )}
      </header>

      <main>
        {/* Hero Section */}
        <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden">
          <div className="absolute inset-0 -z-10">
            <img 
              src="https://images.unsplash.com/photo-1505118380757-91f5f5632de0?auto=format&fit=crop&q=80&w=2000" 
              alt="Ocean Background" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-blue-900/40 via-slate-900/20 to-slate-50"></div>
          </div>
          
          <div className="max-w-7xl mx-auto px-6 md:px-12 w-full">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div 
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 1, ease: "easeOut" }}
              >
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.2, duration: 0.5 }}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-white text-sm font-medium mb-8"
                >
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-400"></span>
                  </span>
                  探索 AI 与医疗的无限可能
                </motion.div>
                <h1 className="text-6xl md:text-8xl font-bold tracking-tight leading-[1] mb-8 text-white drop-shadow-sm">
                  打破边界，<br />
                  <span className="text-blue-400">
                    重塑医疗。
                  </span>
                </h1>
                <p className="text-xl md:text-2xl text-white/90 mb-12 leading-relaxed max-w-xl font-light">
                  我是 Vincent，破界实验室主理人。致力于将前沿的人工智能技术与医疗健康深度融合，探索科技向善的实际落地路径。
                </p>
                <div className="flex flex-wrap gap-6">
                  <motion.a 
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    href="#about" 
                    className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-blue-600 text-white rounded-full font-bold text-lg hover:bg-blue-500 transition-all shadow-xl shadow-blue-600/20"
                  >
                    了解更多 <ArrowRight className="w-5 h-5" />
                  </motion.a>
                  <motion.a 
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    href="#insights" 
                    className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white/10 backdrop-blur-md text-white border border-white/30 rounded-full font-bold text-lg hover:bg-white/20 transition-all"
                  >
                    阅读洞察
                  </motion.a>
                </div>
              </motion.div>
              
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1.2, ease: "easeOut" }}
                className="hidden lg:block relative"
              >
                <div className="relative z-10 w-full aspect-square rounded-full border border-white/10 p-12 backdrop-blur-[2px]">
                  <div className="w-full h-full rounded-full border border-white/20 animate-[spin_20s_linear_infinite] absolute inset-0"></div>
                  <div className="w-full h-full rounded-full border-2 border-dashed border-blue-400/30 animate-[spin_30s_linear_infinite_reverse] absolute inset-0"></div>
                  <div className="w-full h-full flex items-center justify-center">
                    <Brain className="w-32 h-32 text-blue-400 opacity-80" />
                  </div>
                </div>
                {/* Floating elements */}
                <motion.div 
                  animate={{ y: [0, -20, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute top-0 left-0 p-4 bg-white/10 backdrop-blur-xl rounded-2xl border border-white/20 shadow-2xl"
                >
                  <Activity className="w-8 h-8 text-blue-400" />
                </motion.div>
                <motion.div 
                  animate={{ y: [0, 20, 0] }}
                  transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                  className="absolute bottom-10 right-0 p-4 bg-white/10 backdrop-blur-xl rounded-2xl border border-white/20 shadow-2xl"
                >
                  <Stethoscope className="w-8 h-8 text-blue-400" />
                </motion.div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-6 md:px-12">
            <div className="grid md:grid-cols-2 gap-16 items-center">
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-3xl md:text-4xl font-bold mb-6">关于我</h2>
                <div className="space-y-4 text-slate-600 text-lg leading-relaxed">
                  <p>
                    你好，我是 Vincent。我是一名跨界探索者，深耕于人工智能与医疗健康的交叉领域。
                  </p>
                  <p>
                    我相信，AI 不仅仅是提高效率的工具，更是能够从根本上改变疾病诊断、新药研发和患者管理的革命性力量。我的背景涵盖了技术研发与医疗业务洞察，这让我能够站在"破界"的视角，看到单一学科难以发现的机会。
                  </p>
                  <p>
                    在这里，我记录我的思考，分享我的项目，并寻找志同道合的伙伴一起探索未知。
                  </p>
                </div>
              </motion.div>
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="relative"
              >
                <div className="aspect-[3/4] rounded-3xl overflow-hidden bg-slate-100 relative shadow-2xl">
                  <img 
                    src="https://api.studio.google.com/v1/projects/ais-dev-gfynnzy7fsuhjwd5z42teh-375495724561/files/input_file_0.png" 
                    alt="Vincent at work" 
                    className="object-cover w-full h-full"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-blue-900/40 to-transparent"></div>
                </div>
                {/* Decorative elements */}
                <div className="absolute -bottom-10 -right-10 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl -z-10"></div>
                <div className="absolute -top-10 -left-10 w-48 h-48 bg-sky-500/10 rounded-full blur-3xl -z-10"></div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Lab Section - Redesigned */}
        <section id="lab" className="py-32 bg-white relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-200 to-transparent"></div>
          <div className="max-w-7xl mx-auto px-6 md:px-12">
            <div className="flex flex-col lg:flex-row gap-16 items-start">
              <div className="lg:w-1/3 sticky top-32">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                >
                  <h2 className="text-4xl md:text-5xl font-bold mb-8 leading-tight">
                    破界实验室<br />
                    <span className="text-blue-600">探索边界之外</span>
                  </h2>
                  <p className="text-slate-600 text-lg leading-relaxed mb-8">
                    Boundary-Breaking Lab 是一个致力于打破学科壁垒、探索 AI 与前沿科技在医疗、生命科学等领域创新应用的独立研究与实践平台。
                  </p>
                  <div className="flex flex-col gap-4">
                    <div className="flex items-center gap-3 text-slate-800 font-medium">
                      <div className="w-2 h-2 rounded-full bg-blue-600"></div>
                      跨学科研究
                    </div>
                    <div className="flex items-center gap-3 text-slate-800 font-medium">
                      <div className="w-2 h-2 rounded-full bg-blue-600"></div>
                      技术驱动创新
                    </div>
                    <div className="flex items-center gap-3 text-slate-800 font-medium">
                      <div className="w-2 h-2 rounded-full bg-blue-600"></div>
                      社会价值导向
                    </div>
                  </div>
                </motion.div>
              </div>
              
              <div className="lg:w-2/3 grid gap-8">
                {[
                  {
                    icon: <Brain className="w-10 h-10 text-blue-600" />,
                    title: "AI 医疗前沿探索",
                    desc: "研究大语言模型（LLM）、多模态 AI 在临床辅助决策、医学影像分析中的前沿应用。我们不只是讨论 AI，我们构建它。",
                    color: "bg-blue-50"
                  },
                  {
                    icon: <Activity className="w-10 h-10 text-sky-600" />,
                    title: "数字健康产品孵化",
                    desc: "将技术洞察转化为实际的数字健康产品原型，探索改善患者体验与医疗效率的新模式。从 0 到 1 的创新实践。",
                    color: "bg-sky-50"
                  },
                  {
                    icon: <Globe className="w-10 h-10 text-indigo-600" />,
                    title: "跨界知识开源",
                    desc: "建立开源社区，分享医疗 AI 领域的数据集、模型评测标准及行业深度研究报告。让知识在流动中产生价值。",
                    color: "bg-indigo-50"
                  }
                ].map((item, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, x: 30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.2 }}
                    className={`group p-10 rounded-[2.5rem] ${item.color} border border-transparent hover:border-blue-200 transition-all duration-500`}
                  >
                    <div className="flex flex-col md:flex-row gap-8 items-start">
                      <div className="bg-white p-5 rounded-3xl shadow-sm group-hover:scale-110 transition-transform duration-500">
                        {item.icon}
                      </div>
                      <div>
                        <h3 className="text-2xl font-bold mb-4 text-slate-900">{item.title}</h3>
                        <p className="text-slate-600 text-lg leading-relaxed">{item.desc}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Insights Section */}
        <section id="insights" className="py-20 bg-slate-50">
          <div className="max-w-7xl mx-auto px-6 md:px-12">
            <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="max-w-2xl"
              >
                <h2 className="text-3xl md:text-4xl font-bold mb-4">AI 医疗洞察</h2>
                <p className="text-slate-600 text-lg">记录我对行业的观察、技术趋势的分析以及实践过程中的思考。</p>
              </motion.div>
              <a href="#" className="hidden md:flex items-center gap-2 text-blue-600 font-medium hover:text-blue-700 transition-colors group">
                查看全部文章 <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  tag: "行业趋势",
                  title: "大模型在临床辅助诊断中的应用边界与挑战",
                  date: "2024-03-15",
                  readTime: "8 min read",
                  image: "https://picsum.photos/seed/scenery-forest/600/400"
                },
                {
                  tag: "技术解析",
                  title: "医疗数据的隐私计算：如何在不泄露数据的前提下训练 AI",
                  date: "2024-02-28",
                  readTime: "12 min read",
                  image: "https://picsum.photos/seed/scenery-ocean/600/400"
                },
                {
                  tag: "创新实践",
                  title: "AI 驱动的新药研发：从靶点发现到分子生成的范式转移",
                  date: "2024-01-10",
                  readTime: "10 min read",
                  image: "https://picsum.photos/seed/scenery-sky/600/400"
                }
              ].map((post, i) => (
                <motion.article 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group cursor-pointer"
                >
                  <div className="h-48 overflow-hidden">
                    <img 
                      src={post.image} 
                      alt={post.title} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="p-6">
                    <div className="text-xs font-semibold text-blue-600 mb-3 uppercase tracking-wider">
                      {post.tag}
                    </div>
                    <h3 className="text-xl font-bold mb-3 group-hover:text-blue-600 transition-colors line-clamp-2">
                      {post.title}
                    </h3>
                    <div className="flex items-center text-sm text-slate-500 gap-4">
                      <span>{post.date}</span>
                      <span>{post.readTime}</span>
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>
            <div className="mt-8 md:hidden">
              <a href="#" className="flex items-center justify-center gap-2 text-blue-600 font-medium w-full py-3 bg-blue-50 rounded-xl">
                查看全部文章 <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </section>

        {/* Other IPs Section */}
        <section id="ips" className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-6 md:px-12">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="mb-16"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">其他 IP 与项目</h2>
              <p className="text-slate-600 text-lg max-w-2xl">除了深耕医疗 AI，破界实验室还在孵化一系列跨界内容与工具产品。</p>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-6">
              {[
                {
                  title: "AI+X 跨界播客",
                  desc: "对话不同领域的专家，探讨 AI 如何重塑各行各业。已上线 Apple Podcasts 与小宇宙。",
                  icon: <Lightbulb className="w-6 h-6 text-amber-500" />,
                  bg: "bg-amber-50",
                  border: "border-amber-100"
                },
                {
                  title: "MedTech Weekly",
                  desc: "一份专注于全球医疗科技前沿进展的独立 Newsletter，每周日晚准时推送。",
                  icon: <Mail className="w-6 h-6 text-blue-500" />,
                  bg: "bg-blue-50",
                  border: "border-blue-100"
                },
                {
                  title: "OpenMedData 计划",
                  desc: "致力于整理和开源高质量的中文医疗数据集，助力学术研究与模型训练。",
                  icon: <Dna className="w-6 h-6 text-purple-500" />,
                  bg: "bg-purple-50",
                  border: "border-purple-100"
                },
                {
                  title: "临床 AI 助手原型",
                  desc: "基于开源大模型微调的临床病历结构化提取工具，目前处于内部测试阶段。",
                  icon: <Stethoscope className="w-6 h-6 text-rose-500" />,
                  bg: "bg-rose-50",
                  border: "border-rose-100"
                }
              ].map((ip, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className={`p-8 rounded-3xl border ${ip.bg} ${ip.border} flex flex-col sm:flex-row gap-6 items-start hover:shadow-md transition-shadow cursor-pointer group`}
                >
                  <div className="bg-white p-4 rounded-2xl shadow-sm group-hover:scale-110 transition-transform">
                    {ip.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2 flex items-center gap-2">
                      {ip.title}
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-slate-900 group-hover:translate-x-1 transition-all" />
                    </h3>
                    <p className="text-slate-600 leading-relaxed">{ip.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA / Contact - Redesigned */}
        <section className="py-32 bg-slate-50 relative overflow-hidden">
          <div className="max-w-7xl mx-auto px-6 md:px-12">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="bg-blue-600 rounded-[3rem] p-12 md:p-24 text-center text-white relative overflow-hidden shadow-2xl"
            >
              <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
              <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>
              
              <div className="relative z-10 max-w-3xl mx-auto">
                <h2 className="text-4xl md:text-6xl font-bold mb-8">准备好一起破界了吗？</h2>
                <p className="text-xl md:text-2xl text-blue-100 mb-12 font-light">
                  如果你对 AI 医疗感兴趣，或者有好的想法想要交流，欢迎随时联系我。
                </p>
                <motion.a 
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  href="mailto:vincentlyu28@gmail.com" 
                  className="inline-flex items-center justify-center gap-3 px-10 py-5 bg-white text-blue-600 rounded-full font-bold text-xl hover:bg-blue-50 transition-all shadow-xl"
                >
                  <Mail className="w-6 h-6" /> 立即联系
                </motion.a>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-slate-950 text-slate-400 py-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2 text-white font-bold text-lg">
            <Brain className="w-5 h-5 text-blue-500" />
            <span>破界实验室</span>
          </div>
          <div className="text-sm">
            &copy; {new Date().getFullYear()} Vincent. All rights reserved.
          </div>
          <div className="flex flex-wrap justify-center gap-6">
            {[
              { name: '公众号', icon: <Globe className="w-5 h-5" />, href: '#' },
              { name: '小红书', icon: <Activity className="w-5 h-5" />, href: '#' },
              { name: 'X', icon: <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>, href: '#' },
              { name: 'Youtube', icon: <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>, href: '#' },
              { name: '抖音', icon: <Activity className="w-5 h-5" />, href: '#' },
            ].map((social) => (
              <a 
                key={social.name}
                href={social.href} 
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-blue-600 hover:text-white transition-all duration-300"
              >
                {social.icon}
                <span className="text-sm font-medium">{social.name}</span>
              </a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
